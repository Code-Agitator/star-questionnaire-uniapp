"use strict";
require("../common/vendor.js");
require("../service/index.js");
